"use client";

export default function Tutoriales() {
  return (
    <section className="text-center py-10 bg-gray-100">
      <h3 className="text-2xl font-bold text-blue-900 mb-6">Tutoriales</h3>
      <p className="text-gray-700">Aquí puedes insertar videos, documentos o pasos visuales para guiar al usuario.</p>
    </section>
  );
}
