import Header from "@/components/Header"

export default function ConstanciaIdentidadMayorEdad() {
    return(
        <Header/>
    )
}